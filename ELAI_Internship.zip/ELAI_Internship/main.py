import os
import sounddevice as sd
from scipy.io.wavfile import write

import whisper
import torch
import numpy as np

import openai
from dotenv import load_dotenv
load_dotenv()

#import pyperclip

#record audio
def record(duration):
    fs = 44100
    myrecording = sd.rec(int(duration * fs), samplerate=fs, channels=2)
    print("Recording...")
    sd.wait()
    print("Done recording")
    write('ouput.mp3', fs, myrecording)


#transcribe audio file
def transcribe():
    torch.cuda.is_available()
    DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

    model = whisper.load_model("tiny",device=DEVICE)
    # print(
    #     f" Model is {'multilingual' if model.is_multilingual else 'english'} "
    #     #f" and has {sum(np.prod(p.shape) for p in model.parameters()):,} parameters."

    # )
    
    # audio = whisper.load_audio("ouput.mp3")
    # audio = whisper.pad_or_trim(audio)
    # mel = whisper.log_mel_spectrogram(audio).to(model.device)

    # _ , probs = model.detect_language(mel)
    # print(f"Detected language: {max(probs, key=probs.get)}")
    
    # options = whisper.DecodingOptions(language="en",without_timestamps=True,fp16= False)
    # result = whisper.decode(model, mel, options)
    # print(result.text)

    result =model.transcribe('ouput.mp3')
    print(result["text"])
    return result["text"]



def main():
    record(5)
    transcribe()

if __name__ == '__main__':
    main()