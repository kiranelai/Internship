import requests
from bs4 import BeautifulSoup
import pandas as pd
import datetime
import os

# URL of the webpage to scrape
url = 'https://agriplus.in/price/onion/maharashtra/nashik/lasalgaon'

# Send a GET request to the URL
response = requests.get(url)

# Check if the request was successful
if response.status_code == 200:
    # Parse the HTML content
    soup = BeautifulSoup(response.content, 'html.parser')
    table = soup.find('table')  # Find the table element containing the data

    # Extract table headers
    headers = [th.text.strip() for th in table.findAll('th')]

    # Extract table rows
    rows = []
    for row in table.findAll('tr'):
        row_data = [td.text.strip() for td in row.findAll('td')]
        if row_data:  # Skip empty rows
            rows.append(row_data)

    # Convert data to a pandas DataFrame
    df = pd.DataFrame(rows, columns=headers)

    # Generate a filename for the CSV file using current date
    now = datetime.datetime.now()
    filename = f'onionprices.csv'

    # Check if the file already exists
    if os.path.exists(filename):
        # Append data to the existing CSV file
        df.to_csv(filename, mode='a', header=False, index=False)
        print(f'Data appended to {filename} successfully.')
    else:
        # Create a new CSV file and write data to it
        df.to_csv(filename, mode='w', header=True, index=False)
        print(f'New file {filename} created and data written successfully.')
else:
    print('Failed to download webpage')
