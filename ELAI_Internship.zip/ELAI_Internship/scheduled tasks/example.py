import datetime

file = open(r'C:\Users\Kiran Nagarapu\Documents\ELAI_Internship\scheduled tasks\example.txt', 'a')

file.write(f'{datetime.datetime.now()} - the script ran \n')