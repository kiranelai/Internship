#new webiste vs code
import requests
from bs4 import BeautifulSoup
import csv
import datetime

# Function to scrape and append onion prices
def scrape_and_append_prices():
    # Specify the URL
    url = "https://agriplus.in/price/onion/maharashtra/nashik/lasalgaon"

    # Send GET request to the website
    response = requests.get(url)

    # Parse the HTML content
    soup = BeautifulSoup(response.content, "html.parser")

    # Find the table containing the data
    table = soup.find("table")

    # Find all rows in the table
    rows = table.findAll("tr")

    # Get today's date
    today = datetime.datetime.now().date()

    # Open the CSV file in append mode
    with open("prices.csv", "a", newline='') as csv_file:
        csv_writer = csv.writer(csv_file)

        # Loop through each row and extract the data
        for row in rows:
            cells = row.findAll("td")
            if len(cells) > 0:
                date = cells[0].text.strip()
                variety = cells[1].text.strip()
                min_price = cells[2].text.strip()
                max_price = cells[3].text.strip()
                modal_price = cells[4].text.strip()

                # Append the data to the CSV file
                csv_writer.writerow([today, date, variety, min_price, max_price, modal_price])

    # Print a message indicating that the data has been successfully scraped and appended
    print("Data has been scraped and appended to onion_prices.csv")

# Call the function to scrape and append onion prices
scrape_and_append_prices()
